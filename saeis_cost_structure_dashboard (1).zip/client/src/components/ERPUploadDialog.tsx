import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { FileText, Plus, Trash2, Upload, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

type ErpForm = {
  referenceNo: string;
  documentType: "invoice" | "po" | "credit_note";
  supplier: string;
  date: string;
  amount: string;
  description: string;
};

const emptyForm: ErpForm = {
  referenceNo: "",
  documentType: "invoice",
  supplier: "",
  date: "",
  amount: "",
  description: "",
};

export default function ERPUploadDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const [form, setForm] = useState<ErpForm>(emptyForm);
  const [drafts, setDrafts] = useState<ErpForm[]>([]);

  const utils = trpc.useUtils();
  const insert = trpc.saeis.erpRecords.insert.useMutation({
    onSuccess: (res) => {
      toast.success(`تم استيراد ${res.inserted} سجل تشغيل بنجاح`);
      utils.saeis.erpRecords.list.invalidate();
      utils.saeis.matches.list.invalidate();
      utils.saeis.alerts.list.invalidate();
      utils.saeis.dashboard.stats.invalidate();
      setDrafts([]);
      setForm(emptyForm);
      onOpenChange(false);
    },
    onError: (err) => toast.error(`فشل الاستيراد: ${err.message}`),
  });

  const allRecords = useMemo(() => [...drafts, form], [drafts, form]);

  const addDraft = () => {
    const f: ErpForm = { ...form };
    if (!f.referenceNo || !f.amount || !f.date) {
      toast.error("يرجى إدخال المرجع والمبلغ والتاريخ على الأقل");
      return;
    }
    setDrafts((d) => [...d, f]);
    setForm(emptyForm);
  };

  const removeDraft = (i: number) => setDrafts((d) => d.filter((_, idx) => idx !== i));

  const submitDrafts = () => {
    const records = allRecords.filter((r) => r.referenceNo && r.amount && r.date);
    if (records.length === 0) {
      toast.error("لا توجد سجلات صالحة للإرسال");
      return;
    }
    insert.mutate({ records });
  };

  const loadSample = () => {
    setDrafts([
      { referenceNo: "INV-2001", documentType: "invoice", supplier: "مورد جديد", date: "2024-06-01", amount: "1200.00", description: "فاتورة تجريبية" },
      { referenceNo: "INV-2002", documentType: "invoice", supplier: "مورد جديد", date: "2024-06-02", amount: "850.50", description: "فاتورة تجريبية ثانية" },
    ]);
    toast.success("تم تحميل نموذج تجريبي قابل للتعديل");
  };

  const importCsvText = (csv: string) => {
    const lines = csv.split(/\r?\n/).filter((l) => l.trim());
    const rows: ErpForm[] = [];
    for (let i = 0; i < lines.length; i++) {
      const parts = lines[i].split(",");
      if (parts.length < 4) continue;
      // skip header
      if (i === 0 && /reference|invoice|المرجع/i.test(parts[0])) continue;
      rows.push({
        referenceNo: parts[0].trim(),
        documentType: "invoice",
        supplier: (parts[1] || "").trim(),
        date: (parts[2] || "").trim(),
        amount: (parts[3] || "").trim(),
        description: (parts[4] || "").trim(),
      });
    }
    if (rows.length === 0) {
      toast.error("لم يتم العثور على صفوف صالحة — الصيغة: المرجع، المورد، التاريخ (yyyy-mm-dd)، المبلغ، الوصف");
      return;
    }
    setDrafts(rows);
    toast.success(`تم قراءة ${rows.length} سجل من النص`);
  };

  const onCsvFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => importCsvText(String(reader.result || ""));
    reader.readAsText(file);
  };

  const field =
    "w-full bg-[#0A1418] border border-slate-700/50 rounded-lg px-2.5 py-1.5 text-[12px] focus:outline-none focus:border-emerald-500/50 placeholder:text-slate-500";

  const renderForm = (f: ErpForm, set: (v: ErpForm) => void) => (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
      <input className={field} placeholder="المرجع (مثل INV-2001)" value={f.referenceNo} onChange={(e) => set({ ...f, referenceNo: e.target.value })} />
      <select className={field} value={f.documentType} onChange={(e) => set({ ...f, documentType: e.target.value as ErpForm["documentType"] })}>
        <option value="invoice">فاتورة</option>
        <option value="po">أمر شراء</option>
        <option value="credit_note">إشعار دائن</option>
      </select>
      <input className={field} placeholder="المورّد" value={f.supplier} onChange={(e) => set({ ...f, supplier: e.target.value })} />
      <input type="date" className={field} value={f.date} onChange={(e) => set({ ...f, date: e.target.value })} />
      <input className={field} placeholder="المبلغ $" value={f.amount} onChange={(e) => set({ ...f, amount: e.target.value })} />
      <input className={field} placeholder="الوصف" value={f.description} onChange={(e) => set({ ...f, description: e.target.value })} />
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0E1A20] border-emerald-500/30 text-slate-100 max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            إضافة سجلات ERP (تشغيلية)
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            أضف فواتير وأوامر شراء يدويًا أو الصق بيانات CSV — سيقوم المحرك بمطابقتها فورًا مع السجل البنكي
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {renderForm(form, setForm)}
          <div className="flex gap-2">
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-500 text-white" onClick={addDraft}>
              <Plus className="w-3.5 h-3.5 ml-1" />
              إضافة للقائمة
            </Button>
            <Button size="sm" variant="outline" className="border-slate-600/60 text-slate-300" onClick={loadSample}>
              نموذج تجريبي
            </Button>
          </div>

          {allRecords.length > 0 && (
            <div className="rounded-lg border border-slate-700/40 bg-[#0A1418]/60 divide-y divide-slate-800/50 max-h-44 overflow-y-auto">
              {allRecords.map((r, i) => (
                <div key={i} className="flex items-center justify-between px-3 py-1.5 text-[11px]">
                  <span>
                    <span className="text-emerald-300 font-medium">{r.referenceNo}</span>
                    <span className="text-slate-400 mx-2">— {r.supplier || "—"}</span>
                    <span className="text-slate-200">{r.date}</span>
                    <span className="text-amber-200 mx-2">${r.amount}</span>
                  </span>
                  {i < drafts.length ? (
                    <button onClick={() => removeDraft(i)} className="text-red-400 hover:text-red-300">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  ) : null}
                </div>
              ))}
            </div>
          )}

          <div className="rounded-lg border border-dashed border-blue-500/40 bg-blue-500/5 p-3 space-y-2">
            <p className="text-[11px] text-slate-400">
              أو ألصق بيانات CSV (مرجع، مورد، تاريخ yyyy-mm-dd، مبلغ، وصف — سطر لكل سجل):
            </p>
            <textarea
              rows={4}
              className="w-full bg-[#0A1418] border border-slate-700/50 rounded-lg px-2.5 py-1.5 text-[11px] font-mono focus:outline-none focus:border-blue-500/50"
              placeholder={`INV-2001, المورد الأول, 2024-06-01, 1200.00, وصف\nINV-2002, المورد الثاني, 2024-06-02, 850.50, وصف`}
              onChange={(e) => {
                if (e.target.value.trim().length > 8) importCsvText(e.target.value);
              }}
            />
            <div>
              <label className="inline-flex items-center gap-1.5 text-[11px] text-blue-300 cursor-pointer hover:text-blue-200">
                <Upload className="w-3.5 h-3.5" />
                رفع ملف CSV
                <input type="file" accept=".csv,.txt" className="hidden" onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onCsvFile(f);
                  e.target.value = "";
                }} />
              </label>
            </div>
          </div>

          <Button
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white"
            onClick={submitDrafts}
            disabled={insert.isPending || allRecords.length === 0}
          >
            {insert.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin ml-1" />
            ) : (
              <Upload className="w-4 h-4 ml-1" />
            )}
            استيراد {allRecords.length} سجل وتشغيل المطابقة
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
