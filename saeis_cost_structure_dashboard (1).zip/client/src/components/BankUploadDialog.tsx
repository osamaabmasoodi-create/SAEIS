import { useMemo, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Landmark, Plus, Trash2, Upload, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

type BankForm = {
  referenceNo: string;
  date: string;
  amount: string;
  direction: "in" | "out";
  party: string;
  description: string;
};

const emptyForm: BankForm = {
  referenceNo: "",
  date: "",
  amount: "",
  direction: "out",
  party: "",
  description: "",
};

export default function BankUploadDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const [form, setForm] = useState<BankForm>(emptyForm);
  const [drafts, setDrafts] = useState<BankForm[]>([]);

  const utils = trpc.useUtils();
  const insert = trpc.saeis.bankRecords.insert.useMutation({
    onSuccess: (res) => {
      toast.success(`تم استيراد ${res.inserted} حركة بنكية بنجاح`);
      utils.saeis.bankRecords.list.invalidate();
      utils.saeis.matches.list.invalidate();
      utils.saeis.alerts.list.invalidate();
      utils.saeis.dashboard.stats.invalidate();
      setDrafts([]);
      setForm(emptyForm);
      onOpenChange(false);
    },
    onError: (err) => toast.error(`فشل الاستيراد: ${err.message}`),
  });

  const allRecords = useMemo(() => [...drafts, form], [drafts, form]);

  const addDraft = () => {
    const f: BankForm = { ...form };
    if (!f.referenceNo || !f.amount || !f.date) {
      toast.error("يرجى إدخال المرجع والمبلغ والتاريخ على الأقل");
      return;
    }
    setDrafts((d) => [...d, f]);
    setForm(emptyForm);
  };

  const removeDraft = (i: number) => setDrafts((d) => d.filter((_, idx) => idx !== i));

  const submitDrafts = () => {
    const records = allRecords.filter((r) => r.referenceNo && r.amount && r.date);
    if (records.length === 0) {
      toast.error("لا توجد سجلات صالحة للإرسال");
      return;
    }
    insert.mutate({ records });
  };

  const loadSample = () => {
    setDrafts([
      { referenceNo: "TRX-9001", date: "2024-06-02", amount: "1200.00", direction: "out", party: "المورد الأول — فاتورة INV-2001", description: "دفعة بنكية" },
      { referenceNo: "TRX-9002", date: "2024-06-03", amount: "850.50", direction: "out", party: "المورد الثاني", description: "دفعة بنكية" },
    ]);
    toast.success("تم تحميل نموذج تجريبي قابل للتعديل");
  };

  const importCsvText = (csv: string) => {
    const lines = csv.split(/\r?\n/).filter((l) => l.trim());
    const rows: BankForm[] = [];
    for (let i = 0; i < lines.length; i++) {
      const parts = lines[i].split(",");
      if (parts.length < 4) continue;
      if (i === 0 && /trx|reference|المرجع|bank/i.test(parts[0])) continue;
      const dir = parts[2]?.trim().toLowerCase();
      rows.push({
        referenceNo: parts[0].trim(),
        date: (parts[1] || "").trim(),
        amount: (dir === "in" || dir === "وارد" ? "-" : "") + (parts[3] || "").trim(),
        direction: dir === "in" || dir === "وارد" ? "in" : "out",
        party: (parts[4] || "").trim(),
        description: (parts[5] || "").trim(),
      });
    }
    if (rows.length === 0) {
      toast.error("لم يتم العثور على صفوف صالحة — الصيغة: المرجع، التاريخ (yyyy-mm-dd)، الاتجاه (in/out)، المبلغ، الطرف، الوصف");
      return;
    }
    setDrafts(rows);
    toast.success(`تم قراءة ${rows.length} حركة من النص`);
  };

  const onCsvFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => importCsvText(String(reader.result || ""));
    reader.readAsText(file);
  };

  const field =
    "w-full bg-[#0A1418] border border-slate-700/50 rounded-lg px-2.5 py-1.5 text-[12px] focus:outline-none focus:border-emerald-500/50 placeholder:text-slate-500";

  const renderForm = (f: BankForm, set: (v: BankForm) => void) => (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
      <input className={field} placeholder="المرجع البنكي (مثل TRX-9001)" value={f.referenceNo} onChange={(e) => set({ ...f, referenceNo: e.target.value })} />
      <input type="date" className={field} value={f.date} onChange={(e) => set({ ...f, date: e.target.value })} />
      <select className={field} value={f.direction} onChange={(e) => set({ ...f, direction: e.target.value as BankForm["direction"] })}>
        <option value="out">سحب (out)</option>
        <option value="in">إيداع (in)</option>
      </select>
      <input className={field} placeholder="المبلغ $" value={f.amount} onChange={(e) => set({ ...f, amount: e.target.value })} />
      <input className={field} placeholder="الطرف (المستفيد)" value={f.party} onChange={(e) => set({ ...f, party: e.target.value })} />
      <input className={field} placeholder="الوصف" value={f.description} onChange={(e) => set({ ...f, description: e.target.value })} />
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0E1A20] border-emerald-500/30 text-slate-100 max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Landmark className="w-4 h-4 text-blue-400" />
            إضافة حركات السجل البنكي
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            أدخل الحركات البنكية يدويًا أو الصق كشفًا بصيغة CSV — سيطابقها المحرك مع الفواتير فورًا
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {renderForm(form, setForm)}
          <div className="flex gap-2">
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-500 text-white" onClick={addDraft}>
              <Plus className="w-3.5 h-3.5 ml-1" />
              إضافة للقائمة
            </Button>
            <Button size="sm" variant="outline" className="border-slate-600/60 text-slate-300" onClick={loadSample}>
              نموذج تجريبي
            </Button>
          </div>

          {allRecords.length > 0 && (
            <div className="rounded-lg border border-slate-700/40 bg-[#0A1418]/60 divide-y divide-slate-800/50 max-h-44 overflow-y-auto">
              {allRecords.map((r, i) => (
                <div key={i} className="flex items-center justify-between px-3 py-1.5 text-[11px]">
                  <span>
                    <span className="text-blue-300 font-medium">{r.referenceNo}</span>
                    <span className="text-slate-400 mx-2">— {r.party || "—"}</span>
                    <span className="text-slate-200">{r.date}</span>
                    <span className={r.direction === "out" ? "text-red-300 mx-2" : "text-emerald-300 mx-2"}>${r.amount}</span>
                  </span>
                  {i < drafts.length ? (
                    <button onClick={() => removeDraft(i)} className="text-red-400 hover:text-red-300">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  ) : null}
                </div>
              ))}
            </div>
          )}

          <div className="rounded-lg border border-dashed border-blue-500/40 bg-blue-500/5 p-3 space-y-2">
            <p className="text-[11px] text-slate-400">
              أو ألصق كشفًا بصيغة CSV (مرجع، تاريخ yyyy-mm-dd، اتجاه in/out، مبلغ، طرف، وصف):
            </p>
            <textarea
              rows={4}
              className="w-full bg-[#0A1418] border border-slate-700/50 rounded-lg px-2.5 py-1.5 text-[11px] font-mono focus:outline-none focus:border-blue-500/50"
              placeholder={`TRX-9001, 2024-06-02, out, 1200.00, المورد الأول — INV-2001, دفعة بنكية\nTRX-9002, 2024-06-03, out, 850.50, المورد الثاني, دفعة بنكية`}
              onChange={(e) => {
                if (e.target.value.trim().length > 8) importCsvText(e.target.value);
              }}
            />
            <div>
              <label className="inline-flex items-center gap-1.5 text-[11px] text-blue-300 cursor-pointer hover:text-blue-200">
                <Upload className="w-3.5 h-3.5" />
                رفع ملف CSV
                <input type="file" accept=".csv,.txt" className="hidden" onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onCsvFile(f);
                  e.target.value = "";
                }} />
              </label>
            </div>
          </div>

          <Button
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white"
            onClick={submitDrafts}
            disabled={insert.isPending || allRecords.length === 0}
          >
            {insert.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin ml-1" />
            ) : (
              <Upload className="w-4 h-4 ml-1" />
            )}
            استيراد {allRecords.length} حركة وتشغيل المطابقة
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
