/**
 * STYLE — غرفة القرار الزمردية: لوحة تدقيق SAEIS.
 * خلفية كحلية داكنة، زمرد للبيانات السليمة، كهرماني للتنبيه، أحمر حاد للفوارق الحرجة.
 * RTL عربي كامل — لوحة MVP: استيراد سجلات، مطابقة آلية، تنبيهات فورية، تقرير المدير المالي.
 */
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Activity,
  AlertTriangle,
  ArrowDownToLine,
  BadgeDollarSign,
  Banknote,
  BarChart3,
  BellRing,
  ChevronDown,
  CheckCircle2,
  Database,
  FileText,
  Filter,
  Loader2,
  Package,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  XCircle,
} from "lucide-react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import ERPUploadDialog from "@/components/ERPUploadDialog";
import BankUploadDialog from "@/components/BankUploadDialog";

const fadeIn = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.45 },
};

type AlertStatus = "open" | "in_progress" | "resolved";

function severityStyle(severity: string) {
  switch (severity) {
    case "critical":
      return "bg-red-500/15 text-red-300 border-red-500/40";
    case "high":
      return "bg-orange-500/15 text-orange-300 border-orange-500/40";
    case "medium":
      return "bg-amber-500/15 text-amber-300 border-amber-500/40";
    default:
      return "bg-blue-500/15 text-blue-300 border-blue-500/40";
  }
}

function severityLabel(severity: string) {
  switch (severity) {
    case "critical":
      return "حرج";
    case "high":
      return "مرتفع";
    case "medium":
      return "متوسط";
    default:
      return "منخفض";
  }
}

export default function Home() {
  const [uploadOpen, setUploadOpen] = useState<"erp" | "bank" | null>(null);
  const [alertDetail, setAlertDetail] = useState<number | null>(null);

  const utils = trpc.useUtils();
  const seedMutation = trpc.saeis.seed.demo.useMutation({
    onSuccess: () => {
      toast.success("تم تحميل بيانات شركة النور للتجارة بنجاح");
      utils.saeis.dashboard.stats.invalidate();
      utils.saeis.alerts.list.invalidate();
      utils.saeis.erpRecords.list.invalidate();
      utils.saeis.bankRecords.list.invalidate();
      utils.saeis.matches.list.invalidate();
    },
    onError: (e) => toast.error(`تعذّر التحميل: ${e.message}`),
  });

  const clearMutation = trpc.saeis.seed.clear.useMutation({
    onSuccess: () => {
      toast.info("تم مسح البيانات");
      utils.saeis.dashboard.stats.invalidate();
      utils.saeis.alerts.list.invalidate();
      utils.saeis.erpRecords.list.invalidate();
      utils.saeis.bankRecords.list.invalidate();
      utils.saeis.matches.list.invalidate();
    },
  });

  const resolveMutation = trpc.saeis.alerts.resolve.useMutation({
    onSuccess: () => {
      toast.success("تم حل التنبيه");
      utils.saeis.alerts.list.invalidate();
      utils.saeis.dashboard.stats.invalidate();
    },
  });

  const stats = trpc.saeis.dashboard.stats.useQuery();
  const alerts = trpc.saeis.alerts.list.useQuery();
  const erpRecords = trpc.saeis.erpRecords.list.useQuery();
  const bankRecords = trpc.saeis.bankRecords.list.useQuery();

  const statsData = stats.data;

  const statsCards = useMemo(() => {
    if (!statsData) return [];
    return [
      {
        label: "سجلات التشغيل (ERP)",
        value: statsData.erpCount,
        icon: Package,
        color: "text-emerald-300",
        bg: "bg-emerald-500/10 border-emerald-500/30",
      },
      {
        label: "الحركات البنكية",
        value: statsData.bankCount,
        icon: Banknote,
        color: "text-blue-300",
        bg: "bg-blue-500/10 border-blue-500/30",
      },
      {
        label: "مطابقات سليمة",
        value: statsData.matched,
        icon: CheckCircle2,
        color: "text-emerald-300",
        bg: "bg-emerald-500/10 border-emerald-500/30",
      },
      {
        label: "فوارق مكتشفة",
        value: statsData.openAlerts,
        icon: AlertTriangle,
        color: "text-red-300",
        bg: "bg-red-500/10 border-red-500/30",
      },
      {
        label: "قيمة الفوارق (دولار)",
        value: `$${statsData.discrepancyTotal.toLocaleString("en-US", { maximumFractionDigits: 2 })}`,
        icon: BadgeDollarSign,
        color: "text-amber-300",
        bg: "bg-amber-500/10 border-amber-500/30",
      },
      {
        label: "فاتورة بدون حركة",
        value: statsData.unmatched,
        icon: XCircle,
        color: "text-orange-300",
        bg: "bg-orange-500/10 border-orange-500/30",
      },
    ];
  }, [statsData]);

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-[#0A1418] text-slate-100"
      style={{
        backgroundImage:
          "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(16,185,129,0.12), transparent), radial-gradient(ellipse 60% 40% at 90% 10%, rgba(59,130,246,0.08), transparent)",
      }}
    >
      {/* Header */}
      <header className="border-b border-emerald-500/15">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-wide">
                SAEIS
                <span className="text-emerald-400/90 text-sm font-normal mr-2">
                  التدقيق الذكي وربط ERP
                </span>
              </h1>
              <p className="text-[11px] text-slate-400">
                غرفة القرار — مفهوم أولي قابل للفحص (MVP)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              className="border-amber-500/40 text-amber-300 hover:bg-amber-500/10"
              onClick={() => {
                if (confirm("سيتم مسح جميع البيانات الحالية. متابعة؟"))
                  clearMutation.mutate();
              }}
            >
              مسح البيانات
            </Button>
            <Button
              size="sm"
              className="bg-emerald-600 hover:bg-emerald-500 text-white"
              onClick={() => seedMutation.mutate()}
              disabled={seedMutation.isPending}
            >
              {seedMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Database className="w-4 h-4" />
              )}
              تحميل بيانات تجريبية
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* KPI row */}
        <motion.section
          {...fadeIn}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3"
        >
          {statsCards.map((card, i) => (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06, duration: 0.4 }}
              className={`rounded-xl border p-3.5 ${card.bg} backdrop-blur`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] text-slate-300/80">
                  {card.label}
                </span>
                <card.icon className={`w-4 h-4 ${card.color}`} />
              </div>
              <div className={`text-xl font-bold ${card.color}`}>
                {card.value}
              </div>
            </motion.div>
          ))}
        </motion.section>

        {/* Empty state */}
        {statsData &&
          statsData.erpCount === 0 &&
          statsData.bankCount === 0 && (
            <motion.div
              {...fadeIn}
              className="rounded-2xl border border-emerald-500/15 bg-emerald-500/5 p-10 text-center"
            >
              <Sparkles className="w-10 h-10 mx-auto text-emerald-400/70 mb-3" />
              <h2 className="text-lg font-semibold mb-1">
                لوحة SAEIS جاهزة للعمل
              </h2>
              <p className="text-sm text-slate-400 max-w-md mx-auto mb-5">
                ابدأ باستيراد سجلات نظام التشغيل (ERP) والسجل البنكي، وسيقوم
                محرك المطابقة باكتشاف الفوارق تلقائيًا لحظة بلحظة.
              </p>
              <div className="flex items-center justify-center gap-3 flex-wrap">
                <Button
                  className="bg-emerald-600 hover:bg-emerald-500 text-white"
                  onClick={() => seedMutation.mutate()}
                  disabled={seedMutation.isPending}
                >
                  {seedMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Database className="w-4 h-4" />
                  )}
                  تحميل بيانات تجريبية (شركة النور للتجارة)
                </Button>
                <Button
                  variant="outline"
                  className="border-blue-500/40 text-blue-300 hover:bg-blue-500/10"
                  onClick={() => setUploadOpen("erp")}
                >
                  <ArrowDownToLine className="w-4 h-4" />
                  استيراد سجلات ERP
                </Button>
              </div>
            </motion.div>
          )}

        {/* Alerts panel */}
        {statsData && statsData.openAlerts > 0 && (
          <motion.section {...fadeIn} className="space-y-3">
            <div className="flex items-center gap-2">
              <BellRing className="w-4 h-4 text-red-400" />
              <h2 className="text-sm font-semibold text-slate-200">
                تنبيهات فورية للمدير المالي
              </h2>
              <Badge className="bg-red-500/15 text-red-300 border border-red-500/40">
                {statsData.openAlerts}
              </Badge>
            </div>
            <div className="grid md:grid-cols-2 gap-3">
              {alerts.data?.map((alert, i) => (
                <motion.button
                  key={alert.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => setAlertDetail(alert.id)}
                  className={`rounded-xl border p-4 text-right bg-[#0E1A20]/70 backdrop-blur hover:border-emerald-500/40 transition-colors ${severityStyle(alert.severity)}`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="font-semibold text-sm">{alert.title}</span>
                    <span className="text-[10px] opacity-80 shrink-0">
                      {severityLabel(alert.severity)}
                    </span>
                  </div>
                  <p className="text-[12px] opacity-90 leading-relaxed">
                    {alert.details}
                  </p>
                </motion.button>
              ))}
            </div>
          </motion.section>
        )}

        {/* Records tabs */}
        {statsData && (
          <motion.section {...fadeIn}>
            <Tabs defaultValue="erp">
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <TabsList className="bg-[#0E1A20]/70 border border-slate-700/50">
                  <TabsTrigger value="erp" className="data-[state=active]:bg-emerald-600/30 data-[state=active]:text-emerald-300">
                    <Package className="w-3.5 h-3.5 ml-1.5" />
                    سجلات ERP
                  </TabsTrigger>
                  <TabsTrigger value="bank" className="data-[state=active]:bg-blue-600/30 data-[state=active]:text-blue-300">
                    <Banknote className="w-3.5 h-3.5 ml-1.5" />
                    السجل البنكي
                  </TabsTrigger>
                  <TabsTrigger value="matches" className="data-[state=active]:bg-teal-600/30 data-[state=active]:text-teal-300">
                    <RefreshCw className="w-3.5 h-3.5 ml-1.5" />
                    المطابقات
                  </TabsTrigger>
                </TabsList>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10"
                    onClick={() => setUploadOpen("erp")}
                  >
                    <FileText className="w-3.5 h-3.5 ml-1" />
                    إضافة فاتورة
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-blue-500/40 text-blue-300 hover:bg-blue-500/10"
                    onClick={() => setUploadOpen("bank")}
                  >
                    <FileText className="w-3.5 h-3.5 ml-1" />
                    إضافة حركة بنكية
                  </Button>
                </div>
              </div>

              <TabsContent value="erp">
                <RecordsTable type="erp" />
              </TabsContent>
              <TabsContent value="bank">
                <RecordsTable type="bank" />
              </TabsContent>
              <TabsContent value="matches">
                <MatchesTable />
              </TabsContent>
            </Tabs>
          </motion.section>
        )}

        {/* CFO report */}
        {statsData && statsData.erpCount > 0 && (
          <motion.section {...fadeIn}>
            <div className="rounded-2xl border border-emerald-500/20 bg-gradient-to-b from-[#0E1A20] to-[#0B1519] p-5">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-semibold">
                  تقرير المدير المالي — ملخص فوري
                </h2>
              </div>
              <p className="text-[13px] leading-relaxed text-slate-300">
                تم فحص{" "}
                <span className="text-emerald-300 font-semibold">
                  {statsData.erpCount}
                </span>{" "}
                سجل تشغيل مقابل{" "}
                <span className="text-blue-300 font-semibold">
                  {statsData.bankCount}
                </span>{" "}
                حركة بنكية. تم إثبات{" "}
                <span className="text-emerald-300 font-semibold">
                  {statsData.matched}
                </span>{" "}
                مطابقة سليمة، بينما يُظهر{" "}
                <span className="text-red-300 font-semibold">
                  {statsData.openAlerts}
                </span>{" "}
                فارقًا يستدعي المراجعة بقيمة إجمالية{" "}
                <span className="text-amber-300 font-semibold">
                  ${statsData.discrepancyTotal.toLocaleString("en-US", { maximumFractionDigits: 2 })}
                </span>
                .{" "}
                {statsData.unmatched > 0 && (
                  <>
                    كما توجد{" "}
                    <span className="text-orange-300 font-semibold">
                      {statsData.unmatched}
                    </span>{" "}
                    فاتورة بدون حركة بنكية مقابلة.
                  </>
                )}
              </p>
            </div>
          </motion.section>
        )}
      </main>

      <footer className="border-t border-slate-800/60 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 text-center text-[11px] text-slate-500">
          SAEIS — Smart Audit & ERP Integration | مفهوم أولي قابل للفحص (MVP) —
          القرار مبني على أرقام
        </div>
      </footer>

      <ERPUploadDialog open={uploadOpen === "erp"} onOpenChange={(o) => !o && setUploadOpen(null)} />
      <BankUploadDialog open={uploadOpen === "bank"} onOpenChange={(o) => !o && setUploadOpen(null)} />

      <AlertDetailDialog
        open={alertDetail !== null}
        alertId={alertDetail}
        onClose={() => setAlertDetail(null)}
        onResolve={(id) => resolveMutation.mutate({ id })}
      />
    </div>
  );
}

/** ---- Shared record table ---- */
function RecordsTable({ type }: { type: "erp" | "bank" }) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const erpQuery = trpc.saeis.erpRecords.list.useQuery(undefined, { enabled: type === "erp" });
  const bankQuery = trpc.saeis.bankRecords.list.useQuery(undefined, { enabled: type === "bank" });
  const matchesQuery = trpc.saeis.matches.list.useQuery(undefined, { enabled: true });
  const rows = useMemo(() => {
    const recs = type === "erp" ? (erpQuery.data ?? []) : (bankQuery.data ?? []);
    const matches = matchesQuery.data ?? [];
    const keyBy = (m: { erpRecordId?: number | null; bankRecordId?: number | null }) =>
      type === "erp" ? m.erpRecordId : m.bankRecordId;
    const statusOf = (id: number) => {
      const m = matches.find((x) => keyBy(x) === id);
      if (!m) return "pending_review";
      return m.status ?? "pending_review";
    };
    return recs.map((r) => ({ ...r, matchStatus: statusOf(r.id) }));
  }, [type, erpQuery.data, bankQuery.data, matchesQuery.data]);
  const isLoading = type === "erp" ? erpQuery.isLoading : bankQuery.isLoading;

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    return rows.filter((r) => {
      const party = (r as { party?: string | null; supplier?: string | null }).party ?? (r as { party?: string | null; supplier?: string | null }).supplier ?? "";
      const matchesSearch =
        !s ||
        (r.referenceNo ?? "").toLowerCase().includes(s) ||
        party.toLowerCase().includes(s) ||
        String(r.amount).includes(s);
      const matchesStatus =
        statusFilter === "all" || r.matchStatus === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [rows, search, statusFilter]);

  const statusBadge = (status: string) => {
    switch (status) {
      case "matched":
        return (
          <Badge className="bg-emerald-500/15 text-emerald-300 border border-emerald-500/40">
            سليمة
          </Badge>
        );
      case "partial":
        return (
          <Badge className="bg-amber-500/15 text-amber-300 border border-amber-500/40">
            فرق
          </Badge>
        );
      case "unmatched":
        return (
          <Badge className="bg-red-500/15 text-red-300 border border-red-500/40">
            بدون حركة
          </Badge>
        );
      default:
        return (
          <Badge className="bg-slate-500/15 text-slate-300 border border-slate-500/40">
            قيد الفحص
          </Badge>
        );
    }
  };

  return (
    <div className="rounded-xl border border-slate-700/40 bg-[#0E1A20]/60 overflow-hidden">
      <div className="p-3 flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث برقم الفاتورة أو الطرف أو المبلغ..."
            className="w-full bg-[#0A1418] border border-slate-700/50 rounded-lg py-1.5 pr-8 pl-3 text-[12px] focus:outline-none focus:border-emerald-500/50"
          />
        </div>
        <div className="relative">
          <Filter className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-slate-500" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#0A1418] border border-slate-700/50 rounded-lg py-1.5 pr-7 pl-3 text-[12px] focus:outline-none focus:border-emerald-500/50 appearance-none"
          >
            <option value="all">كل الحالات</option>
            <option value="matched">سليمة</option>
            <option value="partial">فرق مبلغ</option>
            <option value="unmatched">بدون حركة</option>
            <option value="pending_review">قيد الفحص</option>
          </select>
          <ChevronDown className="w-3 h-3 absolute left-2 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
        </div>
      </div>
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent border-slate-700/40">
            <TableHead className="text-[11px] text-slate-400">المرجع</TableHead>
            <TableHead className="text-[11px] text-slate-400">
              {type === "erp" ? "المورّد" : "الطرف"}
            </TableHead>
            <TableHead className="text-[11px] text-slate-400">التاريخ</TableHead>
            <TableHead className="text-[11px] text-slate-400 text-left">
              المبلغ
            </TableHead>
            <TableHead className="text-[11px] text-slate-400">الحالة</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            <TableRow>
              <TableCell colSpan={5} className="text-center py-8">
                <Loader2 className="w-5 h-5 animate-spin mx-auto text-emerald-400" />
              </TableCell>
            </TableRow>
          ) : filtered.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} className="text-center py-8 text-slate-500 text-[12px]">
                لا توجد سجلات مطابقة
              </TableCell>
            </TableRow>
          ) : (
            filtered.map((r) => (
              <TableRow key={r.id} className="border-slate-800/50 hover:bg-emerald-500/5">
                <TableCell className="text-[12px] font-medium">
                  {r.referenceNo}
                </TableCell>
                <TableCell className="text-[12px] text-slate-300">
                  {(r as { party?: string | null }).party ?? (r as { supplier?: string | null }).supplier ?? "—"}
                </TableCell>
                <TableCell className="text-[12px] text-slate-400">
                  {new Date(r.date).toLocaleDateString("ar-YE", {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}
                </TableCell>
                <TableCell className="text-[12px] text-left font-semibold text-emerald-200">
                  ${Number(r.amount).toLocaleString("en-US")}
                </TableCell>
                <TableCell>{statusBadge(r.matchStatus)}</TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}

/** ---- Matches table ---- */
function MatchesTable() {
  const matches = trpc.saeis.matches.list.useQuery();

  return (
    <div className="rounded-xl border border-slate-700/40 bg-[#0E1A20]/60 overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent border-slate-700/40">
            <TableHead className="text-[11px] text-slate-400">سجل ERP</TableHead>
            <TableHead className="text-[11px] text-slate-400">
              الحركة البنكية
            </TableHead>
            <TableHead className="text-[11px] text-slate-400 text-left">
              مبلغ ERP
            </TableHead>
            <TableHead className="text-[11px] text-slate-400 text-left">
              مبلغ البنك
            </TableHead>
            <TableHead className="text-[11px] text-slate-400 text-left">
              الفارق
            </TableHead>
            <TableHead className="text-[11px] text-slate-400">النتيجة</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {matches.isLoading ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-8">
                <Loader2 className="w-5 h-5 animate-spin mx-auto text-emerald-400" />
              </TableCell>
            </TableRow>
          ) : (matches.data ?? []).length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-8 text-slate-500 text-[12px]">
                لا توجد مطابقات بعد — قم باستيراد البيانات أولًا
              </TableCell>
            </TableRow>
          ) : (
            (matches.data ?? []).map((m) => (
              <TableRow key={m.id} className="border-slate-800/50 hover:bg-emerald-500/5">
                <TableCell className="text-[12px]">{m.erpReference ?? "—"}</TableCell>
                <TableCell className="text-[12px]">{m.bankReference ?? "—"}</TableCell>
                <TableCell className="text-[12px] text-left">
                  ${Number(m.erpAmount ?? 0).toLocaleString("en-US")}
                </TableCell>
                <TableCell className="text-[12px] text-left">
                  ${Number(m.bankAmount ?? 0).toLocaleString("en-US")}
                </TableCell>
                <TableCell
                  className={`text-[12px] text-left font-semibold ${
                    Number(m.difference ?? 0) === 0
                      ? "text-emerald-300"
                      : "text-red-300"
                  }`}
                >
                  {Number(m.difference ?? 0) === 0
                    ? "$0"
                    : `$${Number(m.difference ?? 0).toLocaleString("en-US", { maximumFractionDigits: 2 })}`}
                </TableCell>
                <TableCell>
                  {m.status === "matched" ? (
                    <Badge className="bg-emerald-500/15 text-emerald-300 border border-emerald-500/40">
                      تطابق كامل
                    </Badge>
                  ) : m.status === "partial" ? (
                    <Badge className="bg-amber-500/15 text-amber-300 border border-amber-500/40">
                      تطابق جزئي
                    </Badge>
                  ) : m.status === "unmatched" ? (
                    <Badge className="bg-red-500/15 text-red-300 border border-red-500/40">
                      غير مطابقة
                    </Badge>
                  ) : (
                    <Badge className="bg-slate-500/15 text-slate-300 border border-slate-500/40">
                      قيد المراجعة
                    </Badge>
                  )}
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}

/** ---- Alert detail dialog ---- */
function AlertDetailDialog({
  open,
  alertId,
  onClose,
  onResolve,
}: {
  open: boolean;
  alertId: number | null;
  onClose: () => void;
  onResolve: (id: number) => void;
}) {
  const alerts = trpc.saeis.alerts.list.useQuery();
  const alert = alerts.data?.find((a) => a.id === alertId);

  if (!alert) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="bg-[#0E1A20] border-emerald-500/30 text-slate-100 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-red-400" />
            <span>{alert.title}</span>
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            تفاصيل التنبيه الفوري
          </DialogDescription>
        </DialogHeader>
        <div className={`rounded-lg border p-3.5 ${severityStyle(alert.severity)}`}>
          <p className="text-[13px] leading-relaxed">{alert.details}</p>
        </div>
        <div className="text-[11px] text-slate-500 flex items-center justify-between">
          <span>
            الحالة: {alert.status === "open" ? "مفتوح" : alert.status === "in_progress" ? "قيد المعالجة" : "محلول"}
          </span>
          <span>
            {new Date(alert.createdAt).toLocaleString("ar-YE")}
          </span>
        </div>
        {alert.status !== "resolved" && (
          <Button
            size="sm"
            className="bg-emerald-600 hover:bg-emerald-500 text-white w-full"
            onClick={() => onResolve(alert.id)}
          >
            <CheckCircle2 className="w-4 h-4 ml-1" />
            وضع علامة: تمت المراجعة
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
