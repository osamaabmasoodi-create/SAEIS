import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ===== SAEIS MVP tables =====

/**
 * سجلات نظام التشغيل (ERP): فواتير، أوامر شراء، إشعارات دائنة.
 */
export const erpRecords = mysqlTable("erp_records", {
  id: int("id").autoincrement().primaryKey(),
  referenceNo: varchar("referenceNo", { length: 64 }).notNull(),
  documentType: mysqlEnum("documentType", ["invoice", "po", "credit_note"])
    .default("invoice")
    .notNull(),
  supplier: varchar("supplier", { length: 200 }),
  date: varchar("date", { length: 32 }).notNull(), // ISO date yyyy-mm-dd
  amount: varchar("amount", { length: 32 }).notNull(), // numeric string, USD
  description: text("description"),
  source: varchar("source", { length: 32 }).default("manual").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ErpRecord = typeof erpRecords.$inferSelect;
export type InsertErpRecord = typeof erpRecords.$inferInsert;

/**
 * السجل البنكي: تدفقات نقدية واردة وصادرة.
 */
export const bankRecords = mysqlTable("bank_records", {
  id: int("id").autoincrement().primaryKey(),
  referenceNo: varchar("referenceNo", { length: 64 }).notNull(),
  date: varchar("date", { length: 32 }).notNull(),
  amount: varchar("amount", { length: 32 }).notNull(),
  direction: mysqlEnum("direction", ["in", "out"]).default("out").notNull(),
  party: varchar("party", { length: 200 }),
  description: text("description"),
  source: varchar("source", { length: 32 }).default("manual").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BankRecord = typeof bankRecords.$inferSelect;
export type InsertBankRecord = typeof bankRecords.$inferInsert;

/**
 * نتائج المطابقة بين سجل ERP وحركة بنكية.
 */
export const matchResults = mysqlTable("matches", {
  id: int("id").autoincrement().primaryKey(),
  erpRecordId: int("erpRecordId"),
  bankRecordId: int("bankRecordId"),
  erpReference: varchar("erpReference", { length: 64 }),
  bankReference: varchar("bankReference", { length: 64 }),
  erpAmount: varchar("erpAmount", { length: 32 }),
  bankAmount: varchar("bankAmount", { length: 32 }),
  difference: varchar("difference", { length: 32 }).default("0"),
  status: mysqlEnum("status", [
    "matched",
    "partial",
    "unmatched",
    "pending_review",
  ]).default("pending_review").notNull(),
  matchedAt: timestamp("matchedAt").defaultNow().notNull(),
});

export type Match = typeof matchResults.$inferSelect;

/**
 * التنبيهات الفورية للمدير المالي.
 */
export const alertResults = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 300 }).notNull(),
  severity: mysqlEnum("severity", ["critical", "high", "medium", "low"])
    .default("medium")
    .notNull(),
  details: text("details"),
  erpRecordId: int("erpRecordId"),
  matchId: int("matchId"),
  status: mysqlEnum("status", ["open", "in_progress", "resolved"])
    .default("open")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export type Alert = typeof alertResults.$inferSelect;

/**
 * إعدادات نظام المطابقة.
 */
export const appSettings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  key: varchar("key", { length: 64 }).notNull().unique(),
  value: varchar("value", { length: 255 }).notNull(),
});